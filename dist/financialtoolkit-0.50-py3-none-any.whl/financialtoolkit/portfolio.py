import numpy as np
import pandas as pd


def get_tracking_error(
    portfolio_returns: pd.Series, benchmark_returns: pd.Series, rolling_window: int = 0
) -> pd.Series:
    """
    Calculate the tracking error, a measure of the deviation of a portfolio's returns
    from its benchmark.

    Args:
        portfolio_returns (pd.Series): A pandas series of portfolio returns.
        benchmark_returns (pd.Series): A pandas series of benchmark returns.
        rolling_window (int, optional): Rolling window size. Defaults to 0.

    Returns:
        pd.Series: A pandas series of tracking error.
    """
    if rolling_window == 0:
        return np.std(portfolio_returns - benchmark_returns)
    else:
        rolling_tracking_error = (
            (portfolio_returns - benchmark_returns).rolling(rolling_window).std()
        )
        return rolling_tracking_error


def get_payoff_ratio(returns: pd.Series, rolling_window: int = 0) -> float | pd.Series:
    """
    Calculate the Payoff Ratio, a ratio that measures the ability of a trading strategy
    to generate profits relative to its losses.

    Args:
        returns (pd.Series): A series of returns.
        rolling_window (int, optional): Rolling window to calculate ratio over.
            Default is 0, which means the ratio will be calculated over the entire series.

    Returns:
        float | pd.Series: The Payoff Ratio value.
    """
    if rolling_window > 0:
        return np.sum(
            returns.where(returns > 0, 0).rolling(rolling_window).sum()
        ) / -np.sum(returns.where(returns < 0, 0).rolling(rolling_window).sum())
    else:
        return np.sum(returns.where(returns > 0, 0)) / -np.sum(
            returns.where(returns < 0, 0)
        )


def get_profit_factor(returns: pd.Series, rolling: int = 0) -> pd.Series:
    """
    Calculate the profit factor, which measures the gross profit of winning trades
    divided by the gross loss of losing trades. A value greater than 1 indicates
    profitability, while a value less than 1 indicates unprofitability.

    Args:
        returns (pd.Series): Series of returns.
        rolling (int, optional): The rolling window size. Default is 0, which
            means that the calculation is not done on a rolling window.

    Returns:
        pd.Series: Series of profit factor values.
    """
    if rolling > 0:
        return returns.rolling(rolling).apply(
            lambda x: x[x > 0].sum() / abs(x[x < 0].sum())
        )
    else:
        return returns[returns > 0].sum() / abs(returns[returns < 0].sum())


def get_jensens_alpha(
    returns: pd.Series,
    benchmark_returns: pd.Series,
    risk_free_rate: float | pd.Series = 0.0,
    rolling_window: int = 0,
) -> pd.Series:
    """
    Calculates the Jensen's alpha for the given returns series relative to the given benchmark returns series.

    Args:
        returns (pd.Series): A series of asset returns.
        benchmark_returns (pd.Series): A series of benchmark returns.
        risk_free_rate (float or pd.Series): The annual risk-free rate, defaults to 0.0.
        rolling_window (int): The rolling window size, defaults to 0 which means no rolling.

    Returns:
        pd.Series: The calculated Jensen's alpha series.
    """
    excess_returns = returns - (risk_free_rate / 252)
    excess_benchmark_returns = benchmark_returns - (risk_free_rate / 252)

    if rolling_window == 0:
        beta, alpha = np.polyfit(excess_benchmark_returns, excess_returns, 1)
        return alpha
    else:
        rolling_beta = (
            excess_benchmark_returns.rolling(rolling_window).cov(
                excess_returns.rolling(rolling_window)
            )
            / excess_benchmark_returns.rolling(rolling_window).var()
        )
        rolling_alpha = (
            excess_returns.rolling(rolling_window).mean()
            - rolling_beta * excess_benchmark_returns.rolling(rolling_window).mean()
        )
        return rolling_alpha


def get_gain_to_pain_ratio(returns: pd.Series, rolling_window: int = 1) -> pd.Series:
    """
    Calculate the gain to pain ratio, a risk-adjusted return ratio that measures the
    return of an investment relative to the drawdown experienced over the same period.

    Args:
        returns (pd.Series): A pandas series of returns.
        rolling_window (int, optional): Rolling window size. Defaults to 0.

    Returns:
        pd.Series: A pandas series of gain to pain ratio.
    """
    if rolling_window == 0:
        return returns.sum() / np.abs(returns[returns < 0].sum())
    else:
        rolling_drawdown = (
            (1 + returns)
            .rolling(rolling_window)
            .apply(lambda x: np.maximum.accumulate(x) - x)
            .max(axis=1)
        )
        rolling_returns = returns.rolling(rolling_window).sum()
        return rolling_returns / np.abs(rolling_drawdown)


def get_tail_ratio(returns: pd.Series, rolling_window: int = 1) -> pd.Series:
    """
    Calculate the tail ratio, a measure of the ratio of the average of the positive
    returns to the absolute value of the average of the negative returns.

    Args:
        returns (pd.Series): A pandas series of returns.
        rolling_window (int, optional): Rolling window size. Defaults to 0.

    Returns:
        pd.Series: A pandas series of tail ratio.
    """
    if rolling_window == 0:
        return np.mean(returns[returns > 0]) / np.abs(np.mean(returns[returns < 0]))
    else:
        rolling_positive_returns = returns[returns > 0].rolling(rolling_window).mean()
        rolling_negative_returns = np.abs(
            returns[returns < 0].rolling(rolling_window).mean()
        )
        return rolling_positive_returns / rolling_negative_returns


def get_common_sense_ratio(returns: pd.Series, rolling_window: int = 0) -> pd.Series:
    """
    Calculate the common sense ratio, a risk-adjusted return ratio that measures the
    return of an investment relative to its maximum drawdown.

    Args:
        returns (pd.Series): A pandas series of returns.
        rolling_window (int, optional): Rolling window size. Defaults to 0.

    Returns:
        pd.Series: A pandas series of common sense ratio.
    """
    if rolling_window == 0:
        return returns.sum() / np.abs(returns.min())
    else:
        rolling_max_drawdown = (
            (1 + returns)
            .rolling(rolling_window)
            .apply(lambda x: np.maximum.accumulate(x) - x)
            .max(axis=1)
        )
        rolling_returns = returns.rolling(rolling_window).sum()
        return rolling_returns / np.abs(rolling_max_drawdown)


def get_calmar_ratio(returns: pd.Series, rolling_window: int = 1) -> pd.Series:
    """
    Calculates the Calmar ratio for the given returns series.

    Args:
        returns (pd.Series): A series of asset returns.
        rolling_window (int): The rolling window size, defaults to 0 which means no rolling.

    Returns:
        pd.Series: The calculated Calmar ratio series.
    """
    if rolling_window == 0:
        max_drawdown = (returns.cummax() - returns).max()
        annualized_return = np.power(returns.add(1).prod(), 252 / len(returns)) - 1
        return annualized_return / max_drawdown
    else:
        rolling_max = returns.rolling(rolling_window).max()
        rolling_drawdown = (rolling_max - returns.rolling(rolling_window)).max()
        rolling_annualized_return = (
            np.power(
                returns.rolling(rolling_window).add(1).apply(lambda x: x.prod()),
                252 / rolling_window,
            )
            - 1
        )
        return rolling_annualized_return / rolling_drawdown


def get_kelly_criterion(returns: pd.Series, rolling_window: int = 1) -> pd.Series:
    """
    Calculates the Kelly criterion for the given returns series.

    Args:
        returns (pd.Series): A series of asset returns.
        rolling_window (int): The rolling window size, defaults to 0 which means no rolling.

    Returns:
        pd.Series: The calculated Kelly criterion series.
    """
    if rolling_window == 0:
        mean_return = returns.mean()
        std_dev = returns.std()
        return mean_return / (std_dev**2)
    else:
        rolling_mean_return = returns.rolling(rolling_window).mean()
        rolling_std_dev = returns.rolling(rolling_window).std()
        return rolling_mean_return / (rolling_std_dev**2)
