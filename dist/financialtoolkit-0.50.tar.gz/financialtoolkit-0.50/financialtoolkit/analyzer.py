import pandas as pd

from financialtoolkit.fundamentals import (
    get_enterprise,
    get_financial_statements,
    get_profile,
    get_quote,
    get_rating,
)
from financialtoolkit.historical import convert_daily_to_yearly, get_historical_data
from financialtoolkit.normalization import convert_financial_statement
from financialtoolkit.ratios.overview import (
    get_efficiency_ratios,
    get_liquidity_ratios,
    get_profitability_ratios,
    get_solvency_ratios,
    get_valuation_ratios,
)
from financialtoolkit.settings import (
    _BALANCE_SHEET_FORMAT_LOCATION,
    _CASH_FLOW_FORMAT_LOCATION,
    _INCOME_FORMAT_LOCATION,
)


class Analyzer:
    def __init__(
        self,
        tickers,
        api_key=None,
        source="FinancialModelingPrep",
        balance_sheet_format_location: str = "",
        income_statement_format_location: str = "",
        cash_flow_statement_format_location: str = "",
    ):
        """
        Initializes an Analyzer object with a ticker or a list of tickers.

        Args:
        tickers (str or list): A string or a list of strings containing the company ticker(s).
        api_key (str): An API key from FinancialModelingPrep.
        source (str): The source of the data. Either FinancialModelingPrep or Custom.
        balance_sheet_format_location (str): The location of the balance sheet format file.
        income_statement_format_location (str): The location of the income statement format file.
        cash_flow_statement_format_location (str): The location of the cash flow statement format file.
        """
        self._source = source
        self._api_key = api_key

        self._balance_sheet_format_location = (
            balance_sheet_format_location
            if balance_sheet_format_location
            else _BALANCE_SHEET_FORMAT_LOCATION
        )

        self._income_statement_format_location = (
            income_statement_format_location
            if income_statement_format_location
            else _INCOME_FORMAT_LOCATION
        )

        self._cash_flow_statement_format_location = (
            cash_flow_statement_format_location
            if cash_flow_statement_format_location
            else _CASH_FLOW_FORMAT_LOCATION
        )

        if isinstance(tickers, str):
            self.tickers = [tickers]
        elif isinstance(tickers, list):
            self.tickers = tickers
        else:
            raise TypeError("Tickers must be a string or a list of strings.")

        if self._source not in ["FinancialModelingPrep", "Custom"]:
            raise ValueError(
                "Please select either FinancialModelingPrep or Custom as the source."
            )
        elif self._source == "Custom" and len(tickers) > 1:
            raise ValueError("The source Custom currently only supports one ticker.")

        # Initialization of Basic Variables
        self._profile: pd.DataFrame = pd.DataFrame()
        self._quote: pd.DataFrame = pd.DataFrame()
        self._enterprise: pd.DataFrame = pd.DataFrame()
        self._rating: pd.DataFrame = pd.DataFrame()

        # Initialization of Historical Variables
        self._daily_historical_data: pd.DataFrame = pd.DataFrame()
        self._weekly_historical_data: pd.DataFrame = pd.DataFrame()
        self._monthly_historical_data: pd.DataFrame = pd.DataFrame()
        self._yearly_historical_data: pd.DataFrame = pd.DataFrame()

        # Initialization of Fundamentals Variables
        self._balance_sheet_statement: pd.DataFrame = pd.DataFrame()
        self._income_statement: pd.DataFrame = pd.DataFrame()
        self._cash_flow_statement: pd.DataFrame = pd.DataFrame()
        self._efficiency_ratios: pd.DataFrame = pd.DataFrame()
        self._liquidity_ratios: pd.DataFrame = pd.DataFrame()
        self._profitability_ratios: pd.DataFrame = pd.DataFrame()
        self._solvency_ratios: pd.DataFrame = pd.DataFrame()
        self._valuation_ratios: pd.DataFrame = pd.DataFrame()

        try:
            # Initialization of Normalization Variables
            self._balance_sheet_statement_generic: pd.DataFrame = pd.read_csv(
                self._balance_sheet_format_location, index_col=self._source
            )["Generic"]
            self._income_statement_generic: pd.DataFrame = pd.read_csv(
                self._income_statement_format_location, index_col=self._source
            )["Generic"]
            self._cash_flow_statement_generic: pd.DataFrame = pd.read_csv(
                self._cash_flow_statement_format_location, index_col=self._source
            )["Generic"]
        except KeyError:
            raise ValueError(
                f"Source {self._source} is not an option. Please ensure "
                "this source and 'Generic' is included as columns "
                "in the normalization files."
            )

    def profile(self):
        """
        Returns a pandas dataframe containing the company profile information for the specified tickers.

        Raises:
            ValueError: If an API key is not defined for FinancialModelingPrep.

        Returns:
            pandas.DataFrame: The company profile information for the specified tickers.
        """
        if not self._api_key and self._source == "FinancialModelingPrep":
            ValueError(
                "Please define an API key from FinancialModelingPrep to use this functionality."
            )

        if self._profile.empty:
            self._profile = get_profile(self.tickers, self._api_key)

        return self._profile

    def quote(self):
        """
        Returns a pandas dataframe containing the stock quote information for the specified tickers.

        Raises:
            ValueError: If an API key is not defined for FinancialModelingPrep.

        Returns:
            pandas.DataFrame: The stock quote information for the specified tickers.
        """
        if not self._api_key and self._source == "FinancialModelingPrep":
            ValueError(
                "Please define an API key from FinancialModelingPrep to use this functionality."
            )

        if self._quote.empty:
            self._quote = get_quote(self.tickers, self._api_key)

        return self._quote

    def enterprise(self, quarter: str = False, limit: str = 100):
        """
        Returns a pandas dataframe containing the enterprise value information for the specified tickers.

        Args:
            quarter (str): The quarter for which the enterprise value is required. Defaults to False.
            limit (str): The number of results to return. Defaults to 100.

        Raises:
            ValueError: If an API key is not defined for FinancialModelingPrep.

        Returns:
            pandas.DataFrame: The enterprise value information for the specified tickers.
        """
        if not self._api_key and self._source == "FinancialModelingPrep":
            ValueError(
                "Please define an API key from FinancialModelingPrep to use this functionality."
            )

        if self._enterprise.empty:
            self._enterprise = get_enterprise(
                self.tickers, self._api_key, quarter, limit
            )

        return self._enterprise

    def rating(self, limit: int = 100):
        """
        Returns a pandas dataframe containing the stock rating information for the specified tickers.

        Args:
            limit (int): The number of results to return. Defaults to 100.

        Raises:
            ValueError: If an API key is not defined for FinancialModelingPrep.

        Returns:
            pandas.DataFrame: The stock rating information for the specified tickers.
        """
        if not self._api_key and self._source == "FinancialModelingPrep":
            ValueError(
                "Please define an API key from FinancialModelingPrep to use this functionality."
            )

        if self._rating.empty:
            self._rating = get_rating(self.tickers, self._api_key, limit)

        return self._rating

    def historical_data(self, start=None, end=None, period: str = "daily"):
        """
        Returns a pandas dataframe containing the historical data for the specified tickers.

        Args:
            start (str): The start date for the historical data. Defaults to None.
            end (str): The end date for the historical data. Defaults to None.
            period (str): The interval at which the historical data should be
            returned - daily, weekly, monthly, or yearly. Defaults to "daily".

        Raises:
            ValueError: If an invalid value is specified for period.

        Returns:
            pandas.DataFrame: The historical data for the specified tickers.
        """
        if period == "daily":
            self._daily_historical_data = get_historical_data(
                self.tickers, start, end, interval="1d"
            )
            return self._daily_historical_data
        elif period == "weekly":
            self._weekly_historical_data = get_historical_data(
                self.tickers, start, end, interval="1wk"
            )
            return self._weekly_historical_data
        elif period == "monthly":
            self._monthly_historical_data = get_historical_data(
                self.tickers, start, end, interval="1mo"
            )
            return self._monthly_historical_data
        elif period == "yearly":
            if self._daily_historical_data.empty:
                self._daily_historical_data = get_historical_data(
                    self.tickers, start, end, interval="1d"
                )

            self._yearly_historical_data = convert_daily_to_yearly(
                self._daily_historical_data
            )
            return self._yearly_historical_data
        else:
            raise ValueError(
                "Please choose from daily, weekly, monthly or yearly as period."
            )

    def balance_sheet_statement(
        self,
        quarter=False,
        limit: int = 100,
        custom_balance_sheet: pd.DataFrame = pd.DataFrame(),
    ):
        """
        Retrieves the balance sheet statement financial data for the company(s) from the specified source.

        Args:
            quarter (bool, optional): Flag to retrieve quarterly or annual data. Defaults to False.

        Returns:
            pd.DataFrame: A pandas DataFrame with the retrieved balance sheet statement data.
        """
        if not self._api_key and self._source == "FinancialModelingPrep":
            raise ValueError(
                "Please define an API key from FinancialModelingPrep to use this functionality "
                "or change the source to custom accompanied with a custom balance sheet."
            )
        elif self._source == "Custom" and not custom_balance_sheet.empty:
            self._balance_sheet_statement = convert_financial_statement(
                custom_balance_sheet, self._balance_sheet_statement_generic
            )
        elif self._balance_sheet_statement.empty:
            self._balance_sheet_statement = get_financial_statements(
                self.tickers,
                "balance",
                self._api_key,
                quarter,
                limit,
                self._balance_sheet_statement_generic,
            )

        return self._balance_sheet_statement

    def income_statement(
        self,
        quarter=False,
        limit: int = 100,
        custom_income_statement: pd.DataFrame = pd.DataFrame(),
    ):
        """
        Retrieves the income statement financial data for the company(s) from the specified source.

        Args:
            quarter (bool, optional): Flag to retrieve quarterly or annual data. Defaults to False.

        Returns:
            pd.DataFrame: A pandas DataFrame with the retrieved income statement data.
        """
        if not self._api_key and self._source == "FinancialModelingPrep":
            raise ValueError(
                "Please define an API key from FinancialModelingPrep to use this functionality "
                "or change the source to custom accompanied with a custom income statement."
            )
        elif self._source == "Custom" and not custom_income_statement.empty:
            self._balance_sheet_statement = convert_financial_statement(
                custom_income_statement, self._income_statement_generic
            )
        elif self._income_statement.empty:
            self._income_statement = get_financial_statements(
                self.tickers,
                "income",
                self._api_key,
                quarter,
                limit,
                self._income_statement_generic,
            )

        return self._income_statement

    def cash_flow_statement(
        self,
        quarter=False,
        limit: int = 100,
        custom_cash_flow_statement: pd.DataFrame = pd.DataFrame(),
    ):
        """
        Retrieves the cash flow statement financial data for the company(s) from the specified source.

        Args:
            quarter (bool, optional): Flag to retrieve quarterly or annual data. Defaults to False.

        Returns:
            pd.DataFrame: A pandas DataFrame with the retrieved cash flow statement data.
        """
        if not self._api_key and self._source == "FinancialModelingPrep":
            raise ValueError(
                "Please define an API key from FinancialModelingPrep to use this functionality "
                "or change the source to custom accompanied with a custom cash flow statement."
            )
        elif self._source == "Custom" and not custom_cash_flow_statement.empty:
            self._balance_sheet_statement = convert_financial_statement(
                custom_cash_flow_statement, self._cash_flow_statement_generic
            )
        elif self._cash_flow_statement.empty:
            self._cash_flow_statement = get_financial_statements(
                self.tickers,
                "cashflow",
                self._api_key,
                quarter,
                limit,
                self._cash_flow_statement_generic,
            )

        return self._cash_flow_statement

    def efficiency_ratios(
        self,
        custom_balance_sheet: pd.DataFrame = pd.DataFrame(),
        custom_income_statement: pd.DataFrame = pd.DataFrame(),
    ):
        """
        Retrieves the cash flow statement financial data for the company(s) from the specified source.

        Args:
            quarter (bool, optional): Flag to retrieve quarterly or annual data. Defaults to False.

        Returns:
            pd.DataFrame: A pandas DataFrame with the retrieved cash flow statement data.
        """
        if not self._api_key and self._source == "FinancialModelingPrep":
            raise ValueError(
                "Please define an API key from FinancialModelingPrep to use this functionality "
                "or change the source to custom accompanied with a custom balance and income statement."
            )

        if self._balance_sheet_statement.empty:
            self._balance_sheet_statement = self.balance_sheet_statement(
                custom_balance_sheet=custom_balance_sheet
            )
        if self._income_statement.empty:
            self._income_statement = self.income_statement(
                custom_income_statement=custom_income_statement
            )

        if self._efficiency_ratios.empty:
            self._efficiency_ratios = get_efficiency_ratios(
                self.tickers, self._balance_sheet_statement, self._income_statement
            )

        return self._efficiency_ratios

    def liquidity_ratios(
        self,
        custom_balance_sheet: pd.DataFrame = pd.DataFrame(),
        custom_income_statement: pd.DataFrame = pd.DataFrame(),
        custom_cash_flow_statement: pd.DataFrame = pd.DataFrame(),
    ):
        """
        Retrieves the cash flow statement financial data for the company(s) from the specified source.

        Args:
            quarter (bool, optional): Flag to retrieve quarterly or annual data. Defaults to False.

        Returns:
            pd.DataFrame: A pandas DataFrame with the retrieved cash flow statement data.
        """
        if not self._api_key and self._source == "FinancialModelingPrep":
            raise ValueError(
                "Please define an API key from FinancialModelingPrep to use this functionality "
                "or change the source to custom accompanied with a custom balance, income "
                "and cash flow statement."
            )

        if self._balance_sheet_statement.empty:
            self._balance_sheet_statement = self.balance_sheet_statement(
                custom_balance_sheet=custom_balance_sheet
            )
        if self._income_statement.empty:
            self._income_statement = self.income_statement(
                custom_income_statement=custom_income_statement
            )
        if self._cash_flow_statement.empty:
            self._cash_flow_statement = self.cash_flow_statement(
                custom_cash_flow_statement=custom_cash_flow_statement
            )

        if self._liquidity_ratios.empty:
            self._liquidity_ratios = get_liquidity_ratios(
                self.tickers,
                self._balance_sheet_statement,
                self._income_statement,
                self._cash_flow_statement,
            )

        return self._liquidity_ratios

    def profitability_ratios(
        self,
        custom_balance_sheet: pd.DataFrame = pd.DataFrame(),
        custom_income_statement: pd.DataFrame = pd.DataFrame(),
        custom_cash_flow_statement: pd.DataFrame = pd.DataFrame(),
    ):
        """
        Retrieves the cash flow statement financial data for the company(s) from the specified source.

        Args:
            quarter (bool, optional): Flag to retrieve quarterly or annual data. Defaults to False.

        Returns:
            pd.DataFrame: A pandas DataFrame with the retrieved cash flow statement data.
        """
        if not self._api_key and self._source == "FinancialModelingPrep":
            raise ValueError(
                "Please define an API key from FinancialModelingPrep to use this functionality "
                "or change the source to custom accompanied with a custom balance, income "
                "and cash flow statement."
            )

        if self._balance_sheet_statement.empty:
            self._balance_sheet_statement = self.balance_sheet_statement(
                custom_balance_sheet=custom_balance_sheet
            )
        if self._income_statement.empty:
            self._income_statement = self.income_statement(
                custom_income_statement=custom_income_statement
            )
        if self._cash_flow_statement.empty:
            self._cash_flow_statement = self.cash_flow_statement(
                custom_cash_flow_statement=custom_cash_flow_statement
            )

        if self._profitability_ratios.empty:
            self._profitability_ratios = get_profitability_ratios(
                self.tickers,
                self._balance_sheet_statement,
                self._income_statement,
                self._cash_flow_statement,
            )

        return self._profitability_ratios

    def solvency_ratios(
        self,
        custom_balance_sheet: pd.DataFrame = pd.DataFrame(),
        custom_income_statement: pd.DataFrame = pd.DataFrame(),
    ):
        """
        Retrieves the cash flow statement financial data for the company(s) from the specified source.

        Args:
            quarter (bool, optional): Flag to retrieve quarterly or annual data. Defaults to False.

        Returns:
            pd.DataFrame: A pandas DataFrame with the retrieved cash flow statement data.
        """
        if not self._api_key and self._source == "FinancialModelingPrep":
            raise ValueError(
                "Please define an API key from FinancialModelingPrep to use this functionality "
                "or change the source to custom accompanied with a custom balance and income statement."
            )

        if self._balance_sheet_statement.empty:
            self._balance_sheet_statement = self.balance_sheet_statement(
                custom_balance_sheet=custom_balance_sheet
            )
        if self._income_statement.empty:
            self._income_statement = self.income_statement(
                custom_income_statement=custom_income_statement
            )

        if self._solvency_ratios.empty:
            self._solvency_ratios = get_solvency_ratios(
                self.tickers,
                self._balance_sheet_statement,
                self._income_statement,
            )

        return self._solvency_ratios

    def valuation_ratios(
        self,
        custom_balance_sheet: pd.DataFrame = pd.DataFrame(),
        custom_income_statement: pd.DataFrame = pd.DataFrame(),
        custom_cash_flow_statement: pd.DataFrame = pd.DataFrame(),
    ):
        """
        Retrieves the cash flow statement financial data for the company(s) from the specified source.

        Args:
            quarter (bool, optional): Flag to retrieve quarterly or annual data. Defaults to False.

        Returns:
            pd.DataFrame: A pandas DataFrame with the retrieved cash flow statement data.
        """
        if not self._api_key and self._source == "FinancialModelingPrep":
            raise ValueError(
                "Please define an API key from FinancialModelingPrep to use this functionality "
                "or change the source to custom accompanied with a custom balance, income "
                "and cash flow statement."
            )

        if self._yearly_historical_data.empty:
            self._yearly_historical_data = self.historical_data(period="yearly")

        if self._balance_sheet_statement.empty:
            self._balance_sheet_statement = self.balance_sheet_statement(
                custom_balance_sheet=custom_balance_sheet
            )
        if self._income_statement.empty:
            self._income_statement = self.income_statement(
                custom_income_statement=custom_income_statement
            )
        if self._cash_flow_statement.empty:
            self._cash_flow_statement = self.cash_flow_statement(
                custom_cash_flow_statement=custom_cash_flow_statement
            )

        if self._valuation_ratios.empty:
            self._valuation_ratios = get_valuation_ratios(
                self.tickers,
                self._yearly_historical_data,
                self._balance_sheet_statement,
                self._income_statement,
                self._cash_flow_statement,
            )

        return self._valuation_ratios
