import pandas as pd


def convert_financial_statement(
    financial_statement: pd.DataFrame,
    format: pd.DataFrame = pd.DataFrame(),
    reverse_dates: bool = False,
):
    """
    Converts financial statements (balance, income, or cash flow statements) based on custom input
    and returns a DataFrame containing the data with the correct naming.

    Args:
        financial_statement (pd.DataFrame): DataFrame containing the financial statement data.
        format (pd.DataFrame): Optional DataFrame containing the names of the financial statement line items to include
                            in the output. Rows should contain the original name of the line item, and columns should
                            contain the desired name for that line item.

    Returns:
        pd.DataFrame: A DataFrame containing the financial statement data. If only one ticker is provided, the
                    returned DataFrame will have a single column containing the data for that company.
    """
    naming = {}

    if not format.empty:
        for name in financial_statement.index:
            try:
                naming[name] = format.loc[name]
            except KeyError:
                continue

        # Select only the columns it could trace back to the format
        financial_statement = financial_statement.loc[list(naming.keys())]
        financial_statement = financial_statement.rename(index=naming)

        if reverse_dates:
            financial_statement = financial_statement[financial_statement.columns[::-1]]

        return financial_statement

    else:
        raise ValueError("Please provide a non-empty format DataFrame.")
